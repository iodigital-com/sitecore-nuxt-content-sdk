import { AnalyticsAdapter } from '@sitecore-content-sdk/analytics-core/internal';
import { H3Event } from 'h3';
/**
 * Defines the AnalyticsMiddlewareAdapter.
 * @public
 */
export interface AnalyticsMiddlewareAdapter extends AnalyticsAdapter {
    /**
     * The type of the adapter.
     */
    type: 'middleware';
}
/**
 * Creates a middleware-based analytics adapter that reads and writes the visitor ID
 * using cookies and can resolve a new client ID from the Edge proxy when needed.
 * The adapter also provides access to the current URL search parameters.
 * @param {H3Event} event - The H3 event object.
 * @returns {AnalyticsMiddlewareAdapter} The analytics middleware adapter.
 * @public
 */
export declare function analyticsMiddlewareAdapter(event: H3Event): AnalyticsMiddlewareAdapter;
/**
 * Retrieves the client ID from the request cookies.
 * @param {H3Event} event
 * @returns {string | null} The client ID or null if not found.
 * @internal
 */
export declare const getClientId: (event: H3Event) => string | null;
//# sourceMappingURL=analytics-adapter.d.ts.map