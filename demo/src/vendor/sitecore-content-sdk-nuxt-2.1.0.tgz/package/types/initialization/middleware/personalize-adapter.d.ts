import { PersonalizeAdapter } from '@sitecore-content-sdk/personalize/internal';
import { H3Event } from 'h3';
/**
 * Defines the PersonalizeMiddlewareAdapter.
 * @public
 */
export interface PersonalizeMiddlewareAdapter extends Required<PersonalizeAdapter> {
    /**
     * The type of the adapter.
     */
    type: 'middleware';
}
/**
 * Creates a middleware-based personalize adapter that reads and writes the profile ID
 * using cookies and can resolve a new profile ID from the Edge proxy when needed.
 * The adapter also provides the user agent from the request headers.
 * @example
 * // server/middleware/personalize.ts
 * export default defineEventHandler(async (event) => {
 *   const adapter = personalizeMiddlewareAdapter(event);
 *   await personalize({ adapter, ... });
 * });
 * @param {H3Event} event - The H3 event object.
 * @returns {PersonalizeMiddlewareAdapter} The personalize middleware adapter.
 * @public
 */
export declare function personalizeMiddlewareAdapter(event: H3Event): PersonalizeMiddlewareAdapter;
//# sourceMappingURL=personalize-adapter.d.ts.map