import { SitecoreCliConfigInput, SitecoreCliConfig } from '@sitecore-content-sdk/content/config';
/**
 * Accepts a `SitecoreCliConfigInput` object and returns the Sitecore Content SDK CLI configuration,
 * updated with the required default values for Nuxt.
 * @param {SitecoreCliConfigInput} cliConfig the cli configuration provided by the application
 * @returns {SitecoreCliConfig} full sitecore cli configuration to use with cli
 * @public
 */
export declare const defineCliConfig: (cliConfig: SitecoreCliConfigInput) => SitecoreCliConfig;
//# sourceMappingURL=define-cli-config.d.ts.map