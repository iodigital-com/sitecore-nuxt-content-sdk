export { defineCliConfig } from './define-cli-config';
//# sourceMappingURL=index.d.ts.map