/**
 * Gets the editing secret from environment variables.
 * @throws {H3Error} When the editing secret is missing or invalid.
 * @returns {string} The editing secret.
 */
export declare const getEditingSecret: () => string;
//# sourceMappingURL=utils.d.ts.map