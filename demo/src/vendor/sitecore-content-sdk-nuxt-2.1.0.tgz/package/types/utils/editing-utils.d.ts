import { H3Event } from 'h3';
import { NativeDataFetcher } from '@sitecore-content-sdk/core';
import { EditingRenderQueryParams, DesignLibraryRenderPreviewData } from '@sitecore-content-sdk/content/editing';
import { AllowedQueryParams, GetAllowedQueryParamsResult } from '../sharedTypes/editing-types';
/**
 * Parses query string and its parameters to required editing parameters.
 * @param {{ [key: string]: string | undefined }} query query string values
 * @returns {EditingRenderQueryParams} editing parameters
 */
export declare const mapEditingParams: (query: {
    [key: string]: string | undefined;
}) => {
    [key: string]: string | undefined;
};
/**
 * Parses the query parameters based on the provided allowed parameters or a resolver function,
 * to extract additional parameters that should be allowed.
 * @param {{ [key: string]: string | undefined }} queryParams Object of query parameters from incoming URL.
 * @param {AllowedQueryParams} allowedParams Allowed parameters to map.
 * @returns Object containing the list of missing required parameters and the allowed query parameters that were extracted.
 * @internal
 */
export declare const getAllowedQueryParams: (queryParams: {
    [key: string]: unknown;
}, allowedParams?: AllowedQueryParams) => GetAllowedQueryParamsResult;
/**
 * Returns the list of required query parameters based on the page editing mode.
 * @param {EditingRenderQueryParams['mode']} mode current page mode
 * @returns {string[]} list of required parameters for validation
 */
export declare const getRequiredEditingParamsList: (mode: EditingRenderQueryParams["mode"]) => string[];
/**
 * Gets the preview cookies to enable preview mode.
 * Sets the site cookie and preview cookie on the internal request so the ProxyMiddleware
 * can read them and bypass the cache.
 * @param {string} site current site name
 * @returns {string[]} list of cookies to set
 */
export declare const getPreviewCookies: (site: string) => string[];
/**
 * Get headers that should be passed along to subsequent requests.
 * @param {Headers} headers Incoming HTTP Headers
 * @returns Object of approved headers
 * @internal
 */
export declare const getHeadersForPropagation: (headers: Headers) => {
    [key: string]: string;
};
/**
 * Performs an internal request to get the HTML for the editing mode.
 * @param {URL} requestUrl URL to send request to
 * @param {object} propagatedQsParams query string params to use with request
 * @param {object} propagatedHeaders headers to use with request
 * @param {string[]} cookies cookies to use with request
 * @param {NativeDataFetcher} dataFetcher NativeDataFetcher instance to send request with
 * @returns {Promise<string>} HTML with editing markup
 */
export declare const getEditingRequestHtml: (requestUrl: URL, propagatedQsParams: {
    [key: string]: string | undefined;
}, propagatedHeaders: {
    [key: string]: string;
}, cookies: string[], dataFetcher: NativeDataFetcher) => Promise<string>;
/**
 * Type guard for Design Library mode.
 * @param {object} data preview data to check
 * @returns true if the data is DesignLibraryRenderPreviewData
 * @public
 */
export declare const isDesignLibraryPreviewData: (data: unknown) => data is DesignLibraryRenderPreviewData;
/**
 * Server URL resolution order (highest to lowest priority):
 * 1. `SITECORE_INTERNAL_EDITING_HOST_URL` environment variable
 * 2. `http://localhost:3000` for XM Cloud deployments
 * 3. Request host header, using https for Vercel/Netlify deployments
 * @param {H3Event} event - The incoming H3 event
 * @returns {string} resolved server URL
 */
export declare const resolveServerUrl: (event: H3Event) => string;
/**
 * Gets the Content-Security-Policy header value.
 * @returns {string} Content-Security-Policy header value
 */
export declare const getCSPHeader: () => string;
/**
 * Nuxt preview cookies enum
 */
export declare const enum PreviewCookies {
    PREVIEW = "sc_preview"
}
//# sourceMappingURL=editing-utils.d.ts.map