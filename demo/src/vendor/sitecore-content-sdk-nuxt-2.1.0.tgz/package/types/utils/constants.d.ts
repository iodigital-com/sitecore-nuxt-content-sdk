/**
 * Headers that should be passed along to (Editing Chromes handler) SSR request.
 * Note these are in lowercase format to match expected `IncomingHttpHeaders`.
 */
export declare const EDITING_PASS_THROUGH_HEADERS: string[];
//# sourceMappingURL=constants.d.ts.map