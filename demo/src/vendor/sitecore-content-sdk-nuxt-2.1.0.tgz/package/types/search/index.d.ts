export * from '@sitecore-content-sdk/vue/search';
//# sourceMappingURL=index.d.ts.map