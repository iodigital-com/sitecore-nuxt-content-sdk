import { Debugger } from '@sitecore-content-sdk/core';
/**
 * Unified debug object containing all debug namespaces from referenced content-sdk packages.
 * @public
 */
declare const debug: Record<string, Debugger>;
export default debug;
//# sourceMappingURL=debug.d.ts.map