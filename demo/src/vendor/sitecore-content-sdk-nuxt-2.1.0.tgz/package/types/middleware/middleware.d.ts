import { H3Event } from 'h3';
import { SiteInfo, SiteResolver } from '@sitecore-content-sdk/content/site';
import { GraphQLClientOptions } from '@sitecore-content-sdk/content/client';
import { GraphQLRequestClientFactory } from '@sitecore-content-sdk/core';
/**
 * Header name used to share the rewrite path between proxies in the middleware chain.
 */
export declare const REWRITE_HEADER_NAME = "x-sc-rewrite";
/**
 *  Header name used by LocaleMiddleware to share the resolved locale with subsequent proxies.
 */
export declare const LOCALE_HEADER_NAME = "x-sc-locale";
/**
 * The interface for the Middleware configuration
 * @public
 */
export type MiddlewareBaseConfig = {
    /**
     * function, determines if the middleware execution should be skipped, based on cookie, header, or other considerations
     * @param {H3Event} event event object from middleware handler
     */
    skip?: (event: H3Event) => boolean;
    /**
     * Fallback hostname in case `host` header is not present
     * @default localhost
     */
    defaultHostname?: string;
    /**
     * Fallback language in locale cannot be extracted from request URL
     * @default 'en'
     */
    defaultLanguage?: string;
    /**
     * Site resolution implementation by name/hostname
     */
    sites: SiteInfo[];
};
/**
 * Middleware handler class to be extended by all middleware implementations
 * @public
 */
export declare abstract class MiddlewareHandler {
    /**
     * Handler method to execute middleware logic
     * @param {H3Event} event
     */
    abstract handle(event: H3Event): Promise<void>;
}
/**
 * Base middleware class with common methods
 * @public
 */
export declare abstract class MiddlewareBase extends MiddlewareHandler {
    protected config: MiddlewareBaseConfig;
    protected defaultHostname: string;
    protected siteResolver: SiteResolver;
    /**
     * @param {MiddlewareBaseConfig} config - Middleware configuration
     */
    constructor(config: MiddlewareBaseConfig);
    /**
     * Determines if mode is preview
     * @param {H3Event} event
     * @returns {boolean} is preview
     */
    protected isPreview(event: H3Event): boolean;
    /**
     * Determines if the request is a Nuxt prefetch request
     * @param {H3Event} event
     * @returns {boolean} is prefetch
     */
    protected isPrefetch(event: H3Event): boolean;
    /**
     * Determines if the middleware should be skipped for the current request.
     * Returns true for Nuxt internal routes, API routes, Sitecore API routes,
     * or when the custom skip function returns true.
     * @param {H3Event} event
     * @returns {boolean} true if the middleware should be skipped
     */
    protected disabled(event: H3Event): boolean;
    /**
     * Provides used language
     * @param {H3Event} event
     * @returns {string} language
     */
    protected getLanguage(event: H3Event): string;
    /**
     * Extract 'host' header.
     * @param {H3Event} event
     * @returns {string | undefined} The host header, `undefined` will be returned instead of the default value when unavailable
     */
    protected getHostHeader(event: H3Event): string | undefined;
    /**
     * Get site information. If site name is stored in cookie, use it, otherwise resolve by hostname
     * - If site can't be resolved by site name cookie use default site info based on provided parameters
     * - If site can't be resolved by hostname, resolves by default hostname
     * @param {H3Event} event
     * @returns {SiteInfo} site information
     */
    protected getSite(event: H3Event): SiteInfo;
    /**
     * Rewrites the request path for subsequent handling.
     * @param {string} rewritePath - The destination path
     * @param {H3Event} event - The incoming H3 event
     * @param {boolean} [skipHeader] - When true, does not write the x-sc-rewrite header
     * @returns {void}
     */
    protected rewrite(rewritePath: string, event: H3Event, skipHeader?: boolean): void;
    /**
     * Creates a new GraphQLRequestClientFactory instance
     * @param {GraphQLClientOptions} graphQLOptions content sdk config
     * @returns {GraphQLRequestClientFactory} GraphQLRequestClientFactory instance
     */
    protected getClientFactory(graphQLOptions: GraphQLClientOptions): GraphQLRequestClientFactory;
}
//# sourceMappingURL=middleware.d.ts.map