import { H3Event } from 'h3';
import { MiddlewareBase, MiddlewareBaseConfig } from './middleware';
import { SitecoreConfig } from '../config';
/**
 * Cookie attributes for the site cookie.
 * @public
 */
export type CookieAttributes = {
    /** The Secure attribute of the site cookie. */
    secure: boolean;
    /** The HttpOnly attribute of the site cookie. */
    httpOnly: boolean;
    /** The SameSite attribute of the site cookie. */
    sameSite?: true | false | 'lax' | 'strict' | 'none' | undefined;
};
/**
 * Configuration for the MultisiteMiddleware.
 * @public
 */
export type MultisiteMiddlewareConfig = MiddlewareBaseConfig & SitecoreConfig['multisite'];
/**
 * Middleware that resolves the active Sitecore site for each request and rewrites
 * the request path to include the site segment.
 *
 * Because Nuxt uses file-based routing with a `[site]` dynamic segment, the middleware
 * always runs regardless of whether multisite is configured with multiple sites.
 * Skipping it would cause 404 errors for regular page requests.
 * This middleware is only needed when your Nuxt app uses multisite routing
 * with a `[site]` dynamic segment. If your app serves a single site, do not
 * register this middleware.
 *
 * Site resolution order:
 * 1. `sc_site` cookie — when in Sitecore preview mode (`sc_preview` cookie present)
 * 2. `sc_site` query string parameter
 * 3. `site` query string parameter (used in Sitecore Page Builder preview)
 * 4. `sc_site` cookie — when `useCookieResolution` returns true
 * 5. Hostname-based resolution via `SiteResolver`
 *
 * On success, rewrites the request URL to `/${siteName}${pathname}` and sets
 * the `sc_site` cookie for downstream middleware.
 * @example
 * // server/middleware/multisite.ts
 * import { MultisiteMiddleware } from '@sitecore-content-sdk/nuxt/middleware';
 *
 * const middleware = new MultisiteMiddleware({
 *   useCookieResolution: () => true,
 *   sites: config.sites,
 * });
 *
 * export default defineEventHandler((event) => middleware.handle(event));
 * @public
 */
export declare class MultisiteMiddleware extends MiddlewareBase {
    protected config: MultisiteMiddlewareConfig;
    /**
     * @param {MultisiteMiddlewareConfig} config - Multisite middleware configuration
     */
    constructor(config: MultisiteMiddlewareConfig);
    /**
     * Handles an incoming request by resolving the active site and rewriting the path.
     *
     * Skips execution for static files, API routes, Nuxt internal routes, and when
     * a custom skip function returns true.
     *
     * In Sitecore preview mode, the site name is read from the `sc_site` cookie to
     * preserve site context during navigation between pages.
     *
     * Errors are caught and logged without re-throwing, so the request continues normally.
     * @param {H3Event} event - The incoming H3 event
     * @returns {Promise<void>}
     */
    handle: (event: H3Event) => Promise<void>;
    /**
     * Determines whether the middleware should be skipped for the current request.
     * Returns `true` for paths containing a file extension (static assets) or
     * when the base disabled check matches (API routes, Nuxt internal routes, custom skip).
     * @param {H3Event} event - The incoming H3 event
     * @returns {boolean} `true` if the middleware should be skipped
     */
    protected disabled(event: H3Event): boolean;
    /**
     * Generates the site-specific rewrite path by prepending the site name segment.
     * @example
     * // '/about' + 'my-site' → '/my-site/about'
     * // 'about' + 'my-site' → '/my-site/about'
     * @param {string} pathname - The pathname to rewrite
     * @param {string} siteName - The resolved site name
     * @returns {string} The rewritten path
     */
    protected getSiteRewrite(pathname: string, siteName: string): string;
}
//# sourceMappingURL=multisite-middleware.d.ts.map