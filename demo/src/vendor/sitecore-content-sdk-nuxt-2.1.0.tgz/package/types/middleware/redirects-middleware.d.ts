import { H3Event } from 'h3';
import { RedirectsService, RedirectsServiceConfig, RedirectInfo } from '@sitecore-content-sdk/content/site';
import { MiddlewareBase, MiddlewareBaseConfig } from './middleware';
import { SitecoreConfig } from '../config';
type RedirectResult = RedirectInfo & {
    matchedQueryString?: string;
};
/**
 * Configuration for the RedirectsMiddleware.
 *
 * Requires either Edge API configuration (`contextId`/`clientContextId`) or local API
 * configuration (`apiHost`/`apiKey`). When neither is present, the middleware initializes
 * without a redirects service and skips execution.
 * @public
 */
export type RedirectsMiddlewareConfig = Omit<RedirectsServiceConfig, 'fetch' | 'clientFactory'> & SitecoreConfig['api']['edge'] & Partial<NonNullable<SitecoreConfig['api']['local']>> & MiddlewareBaseConfig & SitecoreConfig['redirects'] & {
    /**
     * Optional override for the redirects service. When provided, the default
     * RedirectsService is not instantiated.
     */
    redirectsService?: RedirectsService;
};
/**
 * Middleware that fetches redirect rules from Sitecore and applies them to incoming requests.
 *
 * Supports 301, 302, and server transfer (rewrite) redirect types.
 * Handles both static URL patterns and regex-based patterns.
 * Preserves query strings and language prefixes when configured.
 *
 * Requires the `LocaleMiddleware` to run before this middleware so that the
 * `x-sc-locale` response header is set and the locale can be resolved correctly.
 *
 * When neither Edge nor local API configuration is provided, the middleware initializes
 * in a degraded state and skips all redirect processing. This is expected when running
 * locally without a connected Sitecore environment.
 * @example
 * // server/middleware/redirects.ts
 * import { RedirectsMiddleware } from '@sitecore-content-sdk/nuxt/middleware';
 *
 * const middleware = new RedirectsMiddleware({
 *   enabled: true,
 *   contextId: process.env.SITECORE_CONTEXT_ID,
 *   locales: ['en', 'nl'],
 *   sites: config.sites,
 * });
 *
 * export default defineEventHandler((event) => middleware.handle(event));
 * @public
 */
export declare class RedirectsMiddleware extends MiddlewareBase {
    protected config: RedirectsMiddlewareConfig;
    protected redirectsService: RedirectsService | null;
    private locales;
    /**
     * @param {RedirectsMiddlewareConfig} config - Redirects middleware configuration.
     * When neither Edge nor local API configuration is provided, `redirectsService` is set
     * to `null` and redirect processing is disabled.
     */
    constructor(config: RedirectsMiddlewareConfig);
    /**
     * Handles an incoming request by checking for matching redirect rules and applying them.
     *
     * Skips execution when:
     * - The middleware is globally disabled via config
     * - The request targets a static file, API route, or Nuxt internal route
     * - The request is a preview or prefetch
     * - No redirects service is configured
     * - No matching redirect rule is found
     *
     * For 301/302 redirects, sends an HTTP redirect response via `sendRedirect`.
     * For server transfer redirects, rewrites the request path in place.
     *
     * Errors are caught and logged without re-throwing, so the request continues normally.
     * @param {H3Event} event - The incoming H3 event
     * @returns {Promise<void>}
     */
    handle: (event: H3Event) => Promise<void>;
    /**
     * Determines whether the middleware should be skipped for the current request.
     *
     * Returns `true` when the redirects service is not configured, the path contains
     * a file extension (static assets), or the base disabled check matches.
     * @param {H3Event} event - The incoming H3 event
     * @returns {boolean} `true` if the middleware should be skipped
     */
    protected disabled(event: H3Event): boolean;
    /**
     * Handles redirect logic for absolute (external) URLs.
     * Merges query strings when `isQueryStringPreserved` is set on the redirect rule.
     * @param {H3Event} event - The incoming H3 event
     * @param {URL} url - The normalized incoming URL
     * @param {RedirectResult} existsRedirect - The matched redirect rule
     * @returns {Promise<void>}
     */
    protected processAbsoluteUrlTarget(event: H3Event, url: URL, existsRedirect: RedirectResult): Promise<void>;
    /**
     * Handles redirect logic for relative (internal) URLs.
     * Resolves the target locale, merges query strings when configured, and applies
     * any site prefix from the `x-sc-rewrite` response header.
     * @param {H3Event} event - The incoming H3 event
     * @param {URL} url - The normalized incoming URL
     * @param {RedirectResult} existsRedirect - The matched redirect rule
     * @param {string} language - The resolved language for the current request
     * @returns {Promise<void>}
     */
    protected processRelativeUrlTarget(event: H3Event, url: URL, existsRedirect: RedirectResult, language: string): Promise<void>;
    /**
     * Dispatches a redirect or rewrite based on the redirect type.
     *
     * - `REDIRECT_TYPE_301` → HTTP 301 redirect via `sendRedirect`
     * - `REDIRECT_TYPE_302` → HTTP 302 redirect via `sendRedirect`
     * - `REDIRECT_TYPE_SERVER_TRANSFER` → internal rewrite via `this.rewrite`
     * - Unknown types → falls back to a 302 redirect with a console warning
     * @param {H3Event} event - The incoming H3 event
     * @param {string} target - The target URL or path
     * @param {string} type - The redirect type constant
     * @returns {Promise<void>}
     */
    protected dispatchRedirect(event: H3Event, target: string, type: string): Promise<void>;
    /**
     * Finds a matching redirect rule for the current request by comparing the normalized
     * incoming URL against all redirect rules fetched from the Sitecore redirects service.
     *
     * Handles both static URL patterns and regex-based patterns. For regex patterns,
     * language prefixes are stripped before matching and query strings are evaluated separately.
     * @param {H3Event} event - The incoming H3 event
     * @param {string} siteName - The resolved Sitecore site name
     * @returns {Promise<RedirectResult | undefined>} The matched redirect rule, or `undefined` if none found
     */
    protected getExistsRedirect(event: H3Event, siteName: string): Promise<RedirectResult | undefined>;
    /**
     * Normalizes the incoming URL by removing Next.js-style `path=` query parameters
     * that are added when using the `Link` component.
     * @example
     * // '/about/contact?path=about&path=contact' → '/about/contact'
     * @param {URL} url - The URL to normalize
     * @returns {URL} The normalized URL
     */
    protected normalizeUrl(url: URL): URL;
}
export {};
//# sourceMappingURL=redirects-middleware.d.ts.map