import { H3Event } from 'h3';
import { SitecoreConfig } from '@sitecore-content-sdk/content/config';
import { MiddlewareBase, MiddlewareBaseConfig } from './middleware';
/**
 * Configuration for BotTrackingMiddleware.
 * @public
 */
export type BotTrackingMiddlewareConfig = SitecoreConfig['api']['edge'] & MiddlewareBaseConfig;
/**
 * Nuxt server middleware that detects bots and tracks their page views via Sitecore Analytics.
 *
 * Run first in the middleware chain to ensure the bot detection cookie is set
 * before other middlewares execute.
 * @public
 * @example
 * // server/middleware/bot-tracking.ts
 * import { BotTrackingMiddleware } from '@sitecore-content-sdk/nuxt/middleware';
 *
 * const middleware = new BotTrackingMiddleware({
 *   contextId: process.env.SITECORE_EDGE_CONTEXT_ID,
 *   edgeUrl: process.env.SITECORE_EDGE_URL,
 *   sites: config.sites,
 * });
 *
 * export default defineEventHandler((event) => middleware.handle(event));
 */
export declare class BotTrackingMiddleware extends MiddlewareBase {
    protected config: BotTrackingMiddlewareConfig;
    /**
     * @param {BotTrackingMiddlewareConfig} config - Bot tracking middleware configuration.
     */
    constructor(config: BotTrackingMiddlewareConfig);
    /**
     * Handles an incoming request and applies bot tracking if applicable.
     *
     * Skips execution when:
     * - The middleware is disabled via config
     * - The request is a preview
     * - The environment is local or dev (unless `SITECORE_ENABLE_BOT_TRACKING=true`)
     * - The request has no `user-agent` header
     * - The user-agent does not match a known bot
     * - The request is a prefetch
     *
     * On success, sets the bot detection cookie and tracks the page view via `botPageView()`.
     * Errors are caught and logged without re-throwing, so the request continues normally.
     * @param {H3Event} event - The incoming H3 event
     * @returns {Promise<void>}
     */
    handle: (event: H3Event) => Promise<void>;
    /**
     * Returns `true` when bot tracking should be skipped for a local or development environment.
     *
     * Can be overridden by setting `SITECORE_ENABLE_BOT_TRACKING=true`, which forces
     * bot tracking to run even in local environments.
     * @param {H3Event} event - The incoming H3 event
     * @returns {boolean} `true` if the environment is local or dev
     * @internal
     */
    protected shouldSkipForLocalEnvironment(event: H3Event): boolean;
}
//# sourceMappingURL=bot-tracking-middleware.d.ts.map