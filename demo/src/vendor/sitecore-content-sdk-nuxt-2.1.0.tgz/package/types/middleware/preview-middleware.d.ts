import { H3Event } from 'h3';
import { MiddlewareBase, MiddlewareBaseConfig } from './middleware';
/**
 * Configuration for the PreviewMiddleware.
 * @public
 */
export type PreviewMiddlewareConfig = MiddlewareBaseConfig;
/**
 * Middleware handler for bypassing cache in editing and preview mode.
 * Reads the preview cookie set by EditingRenderRoute and sets cache control
 * headers to prevent cached responses from being served to the Page Builder editor.
 * NOTE: This middleware has no dependencies on other proxies
 * and can run at any position in the middleware chain.
 * @public
 * @example
 * // server/middleware/05.preview.ts
 * import { PreviewMiddleware } from '@sitecore-content-sdk/nuxt/middleware';
 * import sites from '../../.sitecore/sites.json';
 *
 * const middleware = new PreviewMiddleware({ sites });
 *
 * export default defineEventHandler((event) => middleware.handle(event));
 */
export declare class PreviewMiddleware extends MiddlewareBase {
    protected config: PreviewMiddlewareConfig;
    /**
     * @param {PreviewMiddlewareConfig} config Preview middleware configuration
     */
    constructor(config: PreviewMiddlewareConfig);
    /**
     * Handles an incoming request.
     * If the request is a preview request, bypasses the cache.
     * Errors are caught and logged, the request always continues.
     * @
     * @param {H3Event} event - The incoming H3 event
     * @returns {Promise<void>}
     */
    handle(event: H3Event): Promise<void>;
    /**
     * Sets cache control headers to prevent the response from being cached.
     * This ensures the Page Builder editor always receives the most recent version of a page.
     * @todo Test of these headers are sufficient for Nitro server caching, or if additional headers are needed
     * @param {H3Event} event - The incoming H3 event
     * @see {@link https://nitro.build/docs/cache} for Nitro server cache configuration
     * @internal
     */
    private bypassCache;
}
//# sourceMappingURL=preview-middleware.d.ts.map