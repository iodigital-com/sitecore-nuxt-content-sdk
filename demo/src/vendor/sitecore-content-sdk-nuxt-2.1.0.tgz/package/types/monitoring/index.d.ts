export { createHealthcheckRoute } from './healthcheck-route';
//# sourceMappingURL=index.d.ts.map