import { H3Event } from 'h3';
import type { AllowedQueryParams } from '../sharedTypes/editing-types';
export type EditingRenderRouteConfig = {
    /**
     * Function used to determine route/page URL to render.
     * This may be necessary for certain custom Nuxt routing configurations.
     * @param {string} itemPath The Sitecore relative item path e.g. '/styleguide'
     * @returns {string} The URL to render
     * @default `${itemPath}`
     */
    resolvePageUrl?: (itemPath: string) => string;
    /**
     * Query string parameters to allow and include in the search params.
     * - Array: each item is a parameter name (string) or an object `{ name, required? }`.
     * - Function: receives the request's query parameter names and returns the list of allowed parameters.
     */
    allowedQueryParams?: AllowedQueryParams;
    /**
     * Optional URL for the internal host of the Sitecore editing environment, used for CORS validation.
     * If not provided, the route handler will attempt to resolve the internal host URL from the incoming request.
     * This is necessary in environments where the internal editing host URL cannot be reliably determined from the request (e.g. certain containerized setups).
     * In such cases, providing this URL explicitly can ensure CORS validation works correctly for requests coming from the Sitecore editing environment.
     * The URL should include the protocol and port (e.g. 'http://editing-host:9000').
     */
    sitecoreInternalEditingHostUrl?: string;
};
/**
 * Creates a route handler for the editing render API route (e.g. '/api/editing/render').
 * Handles GET requests for page rendering and POST requests for server action proxying.
 * @param {EditingRenderRouteConfig} config - The configuration for the route handler.
 * @returns The route handler object with handleGet and handlePost methods.
 * @example
 * // server/api/editing/render.get.ts
 * import { createEditingRenderRoute } from '@sitecore-content-sdk/nuxt/routes';
 * import componentMap from '~/components/component-map';
 *
 * const { handleGet } = createEditingRenderRoute();
 *
 * export default defineEventHandler(handleGet);
 * @example
 * // server/api/editing/render.post.ts
 * import { createEditingRenderRoute } from '@sitecore-content-sdk/nuxt/routes';
 *
 * const { handlePost } = createEditingRenderRoute();
 *
 * export default defineEventHandler(handlePost);
 * @example
 * // server/api/editing/render.options.ts
 * import { createEditingRenderRoute } from '@sitecore-content-sdk/nuxt/routes';
 *
 * const { handleOptions } = createEditingRenderRoute();
 *
 * export default defineEventHandler(handleOptions);
 * @public
 */
export declare const createEditingRenderRoute: (config?: EditingRenderRouteConfig) => {
    handleGet: (event: H3Event) => Promise<void>;
    handleOptions: (event: H3Event) => Promise<void>;
};
//# sourceMappingURL=editing-render-route.d.ts.map