import { H3Event } from 'h3';
import { ComponentMap } from '@sitecore-content-sdk/vue';
import { Metadata } from '@sitecore-content-sdk/core/node-tools';
import { NuxtContentSdkComponent } from '../sharedTypes/component-props';
/**
 * Configuration for the createEditingConfigRoute factory function.
 * @public
 */
export type EditingConfigRouteConfig = {
    /**
     * Components available in the application.
     * Used to report available components to the Sitecore Page Builder.
     */
    components: ComponentMap<NuxtContentSdkComponent> | string[];
    /**
     * Application metadata containing package information.
     */
    metadata: Metadata;
    /**
     * Contains only client and universal components that can be used in client bundles.
     * When provided, Page Builder can distinguish between server and client components.
     */
    clientComponents?: ComponentMap<NuxtContentSdkComponent> | string[];
};
/**
 * Creates a route handler for the editing config API route (e.g. /api/editing/config).
 * Provides configuration information to determine feature compatibility on the Sitecore Page Builder side.
 * @param {EditingConfigRouteConfig} config - The configuration for the editing config route.
 * @returns The route handler object with handle and handleOptions methods.
 * @example
 * // server/api/editing/config.get.ts
 * import { createEditingConfigRoute } from '@sitecore-content-sdk/nuxt/editing';
 * import componentMap from '~/components/component-map';
 * import metadata from '~/package.json';
 *
 * const { handle } = createEditingConfigRoute({ components: componentMap, metadata });
 *
 * export default defineEventHandler(handle);
 * @example
 * // server/api/editing/config.options.ts
 * import { createEditingConfigRoute } from '@sitecore-content-sdk/nuxt/editing';
 * import componentMap from '~/components/component-map';
 * import metadata from '~/package.json';
 *
 * const { handleOptions } = createEditingConfigRoute({ components: componentMap, metadata });
 *
 * export default defineEventHandler(handleOptions);
 * @public
 */
export declare const createEditingConfigRoute: (config: EditingConfigRouteConfig) => {
    handle: (event: H3Event) => Promise<void>;
    handleOptions: (event: H3Event) => Promise<void>;
};
//# sourceMappingURL=editing-config-route.d.ts.map