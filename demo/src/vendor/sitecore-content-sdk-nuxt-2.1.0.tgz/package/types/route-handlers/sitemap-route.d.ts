import { SitecoreClient } from '@sitecore-content-sdk/content/client';
import { SiteInfo } from '@sitecore-content-sdk/content/site';
import { H3Event } from 'h3';
export type SitemapRouteOptions = {
    /**
     * Sitecore client instance used to fetch sitemap.xml content.
     */
    client: SitecoreClient;
    /**
     * List of sites used for site resolution by hostname.
     */
    sites: SiteInfo[];
};
/**
 * Creates a route handler to serve the sitemap.xml file.
 * Fetches sitemap content from Sitecore and serves it as XML.
 *
 * Caching is handled by Nuxt's built-in route rules. Configure cache duration in `nuxt.config.ts`:
 * ```ts
 * routeRules: {
 *   '/sitemap.xml': { cache: { maxAge: 60 } },
 * }
 * ```
 * @param {SitemapRouteOptions} options - The options for the route handler.
 * @returns The route handler.
 * @public
 */
export declare function createSitemapRoute(options: SitemapRouteOptions): {
    handle: (event: H3Event) => Promise<void>;
};
//# sourceMappingURL=sitemap-route.d.ts.map