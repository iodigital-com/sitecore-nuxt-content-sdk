import { H3Event } from 'h3';
import { SitecoreClient } from '@sitecore-content-sdk/content/client';
import { SiteInfo } from '@sitecore-content-sdk/content/site';
export type RobotsRouteOptions = {
    /**
     * Sitecore client instance used to fetch robots.txt content.
     */
    client: SitecoreClient;
    /**
     * List of sites used for site resolution by hostname.
     */
    sites: SiteInfo[];
};
/**
 * Creates a route handler to serve the robots.txt file.
 * Fetches robots.txt content from Sitecore and serves it as plain text.
 * Resolves the correct site based on the incoming request hostname.
 *
 * Caching is handled by Nuxt's built-in route rules. Configure cache duration in `nuxt.config.ts`:
 * ```ts
 * routeRules: {
 *   '/robots.txt': { cache: { maxAge: 60 } },
 * }
 * ```
 * @param {RobotsRouteOptions} options - The options for the route handler.
 * @returns The route handler object with handle method.
 * @example
 * // server/routes/robots.txt.ts
 * import { createRobotsRoute } from '@sitecore-content-sdk/nuxt/routes';
 * import { useSitecoreClient } from '@sitecore-content-sdk/nuxt';
 * import sites from '../../.sitecore/sites.json';
 *
 * const { handle } = createRobotsRoute({ client: useSitecoreClient(), sites });
 *
 * export default defineEventHandler(handle);
 * @public
 */
export declare const createRobotsRoute: (options: RobotsRouteOptions) => {
    handle: (event: H3Event) => Promise<void>;
};
//# sourceMappingURL=robots-route.d.ts.map