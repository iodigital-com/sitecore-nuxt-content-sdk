export { SitecoreConfig, SitecoreConfigInput, defineConfig } from './define-config';
//# sourceMappingURL=index.d.ts.map