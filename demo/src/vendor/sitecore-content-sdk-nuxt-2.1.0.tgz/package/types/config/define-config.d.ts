import { DeepRequired, SitecoreConfigInput as SitecoreConfigInputCore } from '@sitecore-content-sdk/content/config';
/**
 * Provides default Nuxt initial values from env variables for SitecoreConfig
 * @param {SitecoreConfigInput} config optional override values to be written over default config settings
 * @returns default nuxt input config
 */
export declare const getNuxtFallbackConfig: (config?: SitecoreConfigInput) => SitecoreConfigInput;
/**
 * Type to be used as config input in sitecore.config
 * @public
 */
export type SitecoreConfigInput = SitecoreConfigInputCore & {
    /**
     * The internal host URL for the Nuxt application, used for server-side requests for page rendering during editing.
     * This should be the base URL where the Nuxt app is accessible from the server side (e.g., "http://localhost:3000").
     */
    sitecoreInternalEditingHostUrl?: string;
};
/**
 * Final sitecore config type used at runtime. Every property should be populated, either from sitecore.config or built-in fallback values.
 * @public
 */
export type SitecoreConfig = DeepRequired<SitecoreConfigInput>;
/**
 * Accepts a SitecoreConfigInput object and returns full sitecore configuration
 * @param {SitecoreConfigInput} config override values to be written over default config settings
 * @returns {SitecoreConfig} full sitecore configuration to use in application
 * @public
 */
export declare const defineConfig: (config?: SitecoreConfigInput) => SitecoreConfig;
//# sourceMappingURL=define-config.d.ts.map