export { default as DesignLibraryNuxt } from './DesignLibraryNuxt';
//# sourceMappingURL=index.d.ts.map