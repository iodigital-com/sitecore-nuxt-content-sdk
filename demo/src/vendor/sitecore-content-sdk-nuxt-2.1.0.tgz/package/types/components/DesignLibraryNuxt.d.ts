/**
 * Nuxt wrapper around DesignLibrary that wires server-side cache invalidation
 * via useDesignLibraryActions when a component update is received from Design Library.
 * @public
 */
declare const DesignLibraryNuxt: import("vue").DefineComponent<{}, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default DesignLibraryNuxt;
//# sourceMappingURL=DesignLibraryNuxt.d.ts.map