import { NuxtError } from 'nuxt/app';
import type { Ref } from 'vue';
import type { Page } from '@sitecore-content-sdk/content/client';
/**
 * Return type of the useSitecorePage composable.
 * @public
 */
export type UseSitecorePageResult = {
    /**
     * The page data returned from Sitecore, or null if not found.
     */
    page: Ref<Page | null | undefined>;
    /**
     * Error returned by useAsyncData, if any.
     */
    error: Ref<NuxtError<unknown> | undefined>;
    /**
     * Status of the async data fetch.
     */
    status: Ref<'idle' | 'pending' | 'success' | 'error'>;
};
/**
 * Composable that fetches Sitecore page data for the current route.
 *
 * Reads the slug from the route params, determines the correct fetch mode
 * (normal, preview, or Design Library), and fetches the layout data via
 * `useAsyncData` for SSR support.
 *
 * Site and locale are resolved automatically — the multisite middleware
 * rewrites the path to include the site segment, and the locale middleware
 * sets the `x-sc-locale` response header. `SitecoreNuxtClient` handles both.
 *
 * Head links (stylesheets, themes) are injected automatically via `useHead`.
 *
 * Must be used in `[...slug].vue` or any catch-all route page.
 * @public
 * @example
 * // pages/[...slug].vue
 * <script setup>
 * import { useSitecorePage } from '@sitecore-content-sdk/nuxt';
 *
 * const { page, error } = await useSitecorePage();
 *
 * if (!page.value) {
 *   throw createError({ statusCode: 404 });
 * }
 * </script>
 * @returns {Promise<UseSitecorePageResult>} The reactive page result containing `page`, `error`, and `status`.
 */
export declare function useSitecorePage(): Promise<UseSitecorePageResult>;
//# sourceMappingURL=useSitecorePages.d.ts.map