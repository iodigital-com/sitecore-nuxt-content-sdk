import { SitecoreNuxtClient } from '../client/sitecore-nuxt-client';
/**
 * Composable that initializes and returns a `SitecoreNuxtClient` instance
 * using the Nuxt runtime config.
 * @public
 * @example
 * const client = useSitecoreClient();
 * const page = await client.getPage(route.params.slug);
 */
export declare function useSitecoreClient(): SitecoreNuxtClient;
//# sourceMappingURL=useSitecoreClient.d.ts.map