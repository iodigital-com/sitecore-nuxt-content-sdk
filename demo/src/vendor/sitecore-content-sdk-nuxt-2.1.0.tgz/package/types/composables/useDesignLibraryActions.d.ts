import type { ComponentRendering } from '@sitecore-content-sdk/content/layout';
import type { ServerComponentPreviewEventArgs, GeneratedComponentData } from '@sitecore-content-sdk/content/codegen';
/**
 * Model containing the data for a component update received from Design Library.
 * @public
 */
export type ComponentUpdateModel = {
    /** Unique identifier of the component being updated. */
    uid: string;
    /** The updated component rendering data. */
    rendering?: ComponentRendering;
    /**
     * The data needed for generated component to be rendered on the server.
     * Required if update event is coming for a generated component in variant generation mode.
     */
    generatedComponentData?: GeneratedComponentData;
};
/**
 * Model containing the result of a component preview cache update.
 * @public
 */
export type ComponentPreviewModel = {
    /** Unique identifier of the component being updated. */
    uid: string;
    /** The data needed for generated component to be rendered on the server. */
    generatedComponentData?: GeneratedComponentData;
    /** The updated component rendering data. */
    rendering?: ComponentRendering | null;
    /** Error message in case fetching generated component data from secured cache endpoint fails. */
    error?: string;
};
/**
 * Model containing the preview event data received from Design Library in variant generation mode.
 * @public
 */
export type PreviewEventModel = {
    /** Unique identifier of the component being updated. */
    uid: string;
    /** The preview component event arguments in variant generation mode. */
    args: ServerComponentPreviewEventArgs;
};
/**
 * Composable that provides server-side component cache update functions for use with
 * Sitecore Design Library.
 *
 * Uses `refreshNuxtData` to invalidate the page cache after updating component data,
 * triggering a server-side re-render of the affected components.
 * @public
 * @example
 * const { updateComponent, previewComponent } = useDesignLibraryActions();
 *
 * // Update a component from a Design Library event
 * await updateComponent({ uid: 'component-uid', rendering: updatedRendering });
 */
export declare function useDesignLibraryActions(): {
    updateComponent: (updatedComponent: ComponentUpdateModel) => Promise<void>;
    previewComponent: (previewEvent: PreviewEventModel, rendering: ComponentRendering | null, edgeUrl: string | undefined) => Promise<void>;
};
//# sourceMappingURL=useDesignLibraryActions.d.ts.map