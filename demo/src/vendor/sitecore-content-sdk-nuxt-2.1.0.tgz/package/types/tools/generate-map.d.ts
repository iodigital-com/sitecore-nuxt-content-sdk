import { GenerateMapFunction } from '@sitecore-content-sdk/content/tools';
/**
 * Generates a `component-map.ts` file by scanning the provided paths for `.vue` components
 * and writing a typed `ComponentMap` to the destination folder.
 *
 * Components can declare their type explicitly in their `<script>` block:
 * ```ts
 * export const componentType = 'client';
 * ```
 * Without an explicit declaration, components default to `universal`.
 * @param {GenerateMapArgs} params - Configuration for map generation
 * @public
 */
export declare const generateMap: GenerateMapFunction;
//# sourceMappingURL=generate-map.d.ts.map