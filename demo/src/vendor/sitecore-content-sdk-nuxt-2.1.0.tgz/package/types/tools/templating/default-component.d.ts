import { ScaffoldTemplate } from '@sitecore-content-sdk/content/config';
export declare const defaultTemplate: ScaffoldTemplate;
//# sourceMappingURL=default-component.d.ts.map