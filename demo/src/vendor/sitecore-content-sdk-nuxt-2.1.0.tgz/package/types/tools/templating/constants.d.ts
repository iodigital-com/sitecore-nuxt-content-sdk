/**
 * The file extension for nextjs components
 */
export declare const COMPONENT_FILE_EXTENSION = "vue";
//# sourceMappingURL=constants.d.ts.map