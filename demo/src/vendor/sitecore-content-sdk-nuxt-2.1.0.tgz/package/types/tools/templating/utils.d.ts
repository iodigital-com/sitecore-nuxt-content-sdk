import { ComponentFileWithType, ComponentType } from '@sitecore-content-sdk/content/tools';
/**
 * Detects the component type from a `.vue` file by inspecting the `<script>` block
 * for an exported `componentType` constant.
 *
 * Defaults to `universal` when no explicit type is found.
 * @param {string} filePath - Path to the `.vue` component file
 * @returns {ComponentType} 'server', 'client', or 'universal'
 * @internal
 */
export declare function detectComponentType(filePath: string): ComponentType;
/**
 * Returns a list of `.vue` component files with detected component types.
 *
 * Only `.vue` files are included. Composables and utilities in `.ts`/`.js` are excluded.
 * Components that need a custom type must export `componentType` from their `<script>` block:
 * ```ts
 * export const componentType = 'client';
 * ```
 * @param {string[]} paths - Paths to search for components
 * @param {string[]} [exclude] - Glob patterns to exclude
 * @param {boolean} [includeVariants] - Whether to include variant components (e.g. ComponentName.Variant.vue)
 * @returns {ComponentFileWithType[]} Array of components with their detected types
 * @internal
 */
export declare function getComponentListWithTypes(paths: string[], exclude?: string[], includeVariants?: boolean): ComponentFileWithType[];
//# sourceMappingURL=utils.d.ts.map