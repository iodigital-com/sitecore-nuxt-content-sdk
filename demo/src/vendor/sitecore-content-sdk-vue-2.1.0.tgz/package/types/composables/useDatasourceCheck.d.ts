import { type Component, type Ref } from 'vue';
import type { ComponentRendering } from '@sitecore-content-sdk/content/layout';
/**
 * Default component rendered when a datasource is missing in editing mode.
 * @public
 */
export declare const DefaultDatasourceError: import("vue").DefineComponent<{}, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
/**
 * Options for the useDatasourceCheck composable.
 * @public
 */
export interface UseDatasourceCheckOptions {
    /**
     * A component that is rendered when a datasource is missing during editing.
     * If unspecified, a default component with message is displayed.
     */
    editingErrorComponent?: Component;
}
/**
 * Composable that checks whether a Sitecore datasource is present and determines
 * what to render depending on page mode.
 *
 * Returns:
 * - `'component'` when the datasource is present or page is in Design Library mode
 * - `'error'` when the datasource is missing in editing mode
 * - `'null'` when the datasource is missing in normal mode
 * @param {Ref<ComponentRendering>} rendering - The component rendering ref
 * @param {UseDatasourceCheckOptions} [options] - Optional composable options
 * @returns {{ renderState, errorComponent }} render state and error component to use
 * @public
 * @example
 * ```vue
 * <script setup lang="ts">
 * import { toRef } from 'vue';
 * import { useDatasourceCheck } from '../enhancers/useDatasourceCheck';
 *
 * const props = defineProps<{ rendering: ComponentRendering }>();
 * const { renderState, errorComponent } = useDatasourceCheck(toRef(props, 'rendering'));
 * </script>
 *
 * <template>
 *   <component :is="errorComponent" v-if="renderState === 'error'" />
 *   <template v-else-if="renderState === 'component'">
 *     <!-- component content -->
 *   </template>
 * </template>
 * ```
 */
export declare function useDatasourceCheck(rendering: Ref<ComponentRendering>, options?: UseDatasourceCheckOptions): {
    renderState: import("vue").ComputedRef<"error" | "component" | "null">;
    errorComponent: import("vue").ComputedRef<Component>;
};
//# sourceMappingURL=useDatasourceCheck.d.ts.map