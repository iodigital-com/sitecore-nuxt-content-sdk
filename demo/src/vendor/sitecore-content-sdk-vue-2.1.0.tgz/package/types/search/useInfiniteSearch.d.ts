import type { MaybeRefOrGetter } from 'vue';
import { SearchStatus } from './utils';
import { SearchDocument, SearchParameters } from '@sitecore-content-sdk/search';
/**
 * Options for the useInfiniteSearch composable.
 * @public
 */
export interface UseInfiniteSearchOptions<T extends SearchDocument = SearchDocument> {
    /**
     * The query string to search for.
     * By default empty string is used.
     */
    query?: MaybeRefOrGetter<string | undefined>;
    /**
     * The ID of the search index to use.
     */
    searchIndexId: MaybeRefOrGetter<string>;
    /**
     * Number of results per page.
     * @default 10
     */
    pageSize?: MaybeRefOrGetter<number>;
    /**
     * Specifies the sorting of the search results.
     */
    sort?: MaybeRefOrGetter<SearchParameters<T>['sort']>;
    /**
     * Specifies whether the search should automatically run.
     * @default true
     */
    enabled?: MaybeRefOrGetter<boolean>;
}
/**
 * The state of the useInfiniteSearch composable.
 * @public
 */
export interface UseInfiniteSearchState<T extends SearchDocument = SearchDocument> {
    /** The search results. */
    results: T[];
    /** Total number of results across all pages. */
    total: number;
    /** Total number of pages available based on `total` and `pageSize`. */
    totalPages: number;
    /** The error object if the last search request failed, or null if no error occurred. */
    error: Error | null;
    /**
     * The status of the initial search request.
     * - 'idle' if no search request has been made yet.
     * - 'loading' if a search request is currently in progress.
     * - 'success' if a search request was successful.
     * - 'error' if a search request failed.
     * @default 'idle'
     */
    status: SearchStatus;
    /**
     * The status of the "load more" request.
     * - 'idle' if no "load more" request has been made yet.
     * - 'loading' if a "load more" request is currently in progress.
     * - 'error' if a "load more" request failed.
     * @default 'idle'
     */
    loadMoreStatus: Omit<SearchStatus, 'success'>;
    /** Load the next page of results. */
    loadMore: () => void;
    /** Whether there are more results available. */
    hasNextPage: boolean;
    /** Whether a search request is currently in progress. */
    isLoading: boolean;
    /** Whether the search request was successful. */
    isSuccess: boolean;
    /** Whether the search request failed. */
    isError: boolean;
    /** Whether a search request for more results is currently in progress. */
    isLoadingMore: boolean;
    /** Whether the search request for more results failed. */
    isLoadingMoreError: boolean;
}
/**
 * Vue composable for performing infinite search queries.
 * @param {UseInfiniteSearchOptions} options - Configuration options for the infinite search composable.
 * @returns {UseInfiniteSearchState} The infinite search state as reactive computed properties.
 * @throws {Error} if the search index ID is not provided.
 * @public
 * @example
 * // Basic usage with load more button
 * const { results, isLoading, hasNextPage, loadMore } = useInfiniteSearch({
 *   searchIndexId: 'my-index',
 *   query: 'sitecore',
 * });
 * @example
 * // With reactive query
 * const query = ref('');
 *
 * const { results, total, isLoading, isLoadingMore, hasNextPage, loadMore } = useInfiniteSearch({
 *   searchIndexId: 'my-index',
 *   query,
 *   pageSize: 20,
 * });
 */
export declare function useInfiniteSearch<T extends SearchDocument = SearchDocument>(options: UseInfiniteSearchOptions<T>): {
    results: import("vue").ComputedRef<T[]>;
    total: import("vue").ComputedRef<number>;
    totalPages: import("vue").ComputedRef<number>;
    error: import("vue").ComputedRef<Error | null>;
    status: import("vue").ComputedRef<SearchStatus>;
    loadMoreStatus: import("vue").ComputedRef<{
        readonly [x: number]: string;
        [Symbol.iterator]: () => StringIterator<string>;
        link: (url: string) => string;
        search: {
            (regexp: string | RegExp): number;
            (searcher: {
                [Symbol.search](string: string): number;
            }): number;
        };
        small: () => string;
        sub: () => string;
        sup: () => string;
        readonly length: number;
        concat: (...strings: string[]) => string;
        slice: (start?: number, end?: number) => string;
        indexOf: (searchString: string, position?: number) => number;
        lastIndexOf: (searchString: string, position?: number) => number;
        includes: (searchString: string, position?: number) => boolean;
        toString: () => string;
        charAt: (pos: number) => string;
        charCodeAt: (index: number) => number;
        localeCompare: {
            (that: string): number;
            (that: string, locales?: string | string[], options?: Intl.CollatorOptions): number;
            (that: string, locales?: Intl.LocalesArgument, options?: Intl.CollatorOptions): number;
        };
        match: {
            (regexp: string | RegExp): RegExpMatchArray | null;
            (matcher: {
                [Symbol.match](string: string): RegExpMatchArray | null;
            }): RegExpMatchArray | null;
        };
        replace: {
            (searchValue: string | RegExp, replaceValue: string): string;
            (searchValue: string | RegExp, replacer: (substring: string, ...args: any[]) => string): string;
            (searchValue: {
                [Symbol.replace](string: string, replaceValue: string): string;
            }, replaceValue: string): string;
            (searchValue: {
                [Symbol.replace](string: string, replacer: (substring: string, ...args: any[]) => string): string;
            }, replacer: (substring: string, ...args: any[]) => string): string;
        };
        split: {
            (separator: string | RegExp, limit?: number): string[];
            (splitter: {
                [Symbol.split](string: string, limit?: number): string[];
            }, limit?: number): string[];
        };
        substring: (start: number, end?: number) => string;
        toLowerCase: () => string;
        toLocaleLowerCase: {
            (locales?: string | string[]): string;
            (locales?: Intl.LocalesArgument): string;
        };
        toUpperCase: () => string;
        toLocaleUpperCase: {
            (locales?: string | string[]): string;
            (locales?: Intl.LocalesArgument): string;
        };
        trim: () => string;
        substr: (from: number, length?: number) => string;
        valueOf: () => string;
        codePointAt: (pos: number) => number | undefined;
        endsWith: (searchString: string, endPosition?: number) => boolean;
        normalize: {
            (form: "NFC" | "NFD" | "NFKC" | "NFKD"): string;
            (form?: string): string;
        };
        repeat: (count: number) => string;
        startsWith: (searchString: string, position?: number) => boolean;
        anchor: (name: string) => string;
        big: () => string;
        blink: () => string;
        bold: () => string;
        fixed: () => string;
        fontcolor: (color: string) => string;
        fontsize: {
            (size: number): string;
            (size: string): string;
        };
        italics: () => string;
        strike: () => string;
        padStart: (maxLength: number, fillString?: string) => string;
        padEnd: (maxLength: number, fillString?: string) => string;
        trimEnd: () => string;
        trimStart: () => string;
        trimLeft: () => string;
        trimRight: () => string;
        matchAll: (regexp: RegExp) => RegExpStringIterator<RegExpExecArray>;
    }>;
    hasNextPage: import("vue").ComputedRef<boolean>;
    loadMore: () => void;
    isLoading: import("vue").ComputedRef<boolean>;
    isSuccess: import("vue").ComputedRef<boolean>;
    isError: import("vue").ComputedRef<boolean>;
    isLoadingMore: import("vue").ComputedRef<boolean>;
    isLoadingMoreError: import("vue").ComputedRef<boolean>;
};
//# sourceMappingURL=useInfiniteSearch.d.ts.map