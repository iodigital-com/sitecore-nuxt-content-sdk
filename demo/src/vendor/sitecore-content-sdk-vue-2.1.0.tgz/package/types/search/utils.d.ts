import { SearchService } from '@sitecore-content-sdk/search';
export declare const DEFAULT_PAGE_SIZE = 10;
/**
 * The status of a search request.
 * @public
 */
export type SearchStatus = 'idle' | 'loading' | 'success' | 'error';
/**
 * Composable to initialize and manage SearchService.
 */
export declare function useSearchService(): import("vue").ComputedRef<SearchService | null>;
/**
 * Calculates the number of items to skip before returning results.
 * @param {number} page - The current page number (1-indexed).
 * @param {number} pageSize - The number of results per page.
 * @returns The number of items to skip before returning results.
 */
export declare const getOffset: (page: number, pageSize: number) => number;
//# sourceMappingURL=utils.d.ts.map