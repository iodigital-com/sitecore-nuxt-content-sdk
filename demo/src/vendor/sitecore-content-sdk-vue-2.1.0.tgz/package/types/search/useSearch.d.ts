import { MaybeRefOrGetter } from 'vue';
import { SearchDocument, SearchParameters } from '@sitecore-content-sdk/search';
import { SearchStatus } from './utils';
/**
 * Options for the useSearch composable.
 * @public
 */
export interface UseSearchOptions<T extends SearchDocument = SearchDocument> {
    /**
     * The query string to search for.
     * By default empty string is used.
     */
    query?: MaybeRefOrGetter<string | undefined>;
    /**
     * The current page number (1-indexed).
     * If not provided, the search will start on page 1.
     */
    page?: MaybeRefOrGetter<number>;
    /**
     * The ID of the search index to use.
     */
    searchIndexId: MaybeRefOrGetter<string>;
    /**
     * Number of results per page.
     * @default 10
     */
    pageSize?: MaybeRefOrGetter<number>;
    /**
     * Specifies the sorting of the search results.
     */
    sort?: MaybeRefOrGetter<SearchParameters<T>['sort']>;
    /**
     * Specifies whether the search should automatically run.
     * @default true
     */
    enabled?: MaybeRefOrGetter<boolean>;
    /**
     * Specifies whether the previous search results should be kept when fetching new results.
     * @default false
     */
    keepPreviousData?: MaybeRefOrGetter<boolean>;
}
/**
 * The state of the useSearch composable.
 * @public
 */
export interface UseSearchState<T extends SearchDocument = SearchDocument> {
    /** The search results. */
    results: T[];
    /** Total number of results across all pages. */
    total: number;
    /** Total number of pages available based on `total` and `pageSize`. */
    totalPages: number;
    /** The error object if the last search request failed, or null if no error occurred. */
    error: Error | null;
    /**
     * The status of the search.
     * - 'idle' if no search request has been made yet.
     * - 'loading' if a search request is currently in progress.
     * - 'success' if a search request was successful.
     * - 'error' if a search request failed.
     * @default 'idle'
     */
    status: SearchStatus;
    /** Whether a search request is currently in progress. */
    isLoading: boolean;
    /** Whether the search request was successful. */
    isSuccess: boolean;
    /** Whether the search request failed. */
    isError: boolean;
    /**
     * Whether the search results from the previous query are returned.
     * Will be `true` if `keepPreviousData` is set.
     */
    isPreviousData: boolean;
}
/**
 * Vue composable for performing search queries with pagination.
 * @param {UseSearchOptions} options - Configuration options for the search composable.
 * @returns {UseSearchState} The search state as reactive computed properties.
 * @throws {Error} if the search index ID is not provided.
 * @public
 * @example
 * // Basic usage in a component
 * const { results, total, isLoading, isError, error } = useSearch({
 *   searchIndexId: 'my-index',
 *   query: 'sitecore',
 * });
 * @example
 * // With reactive query and pagination
 * const query = ref('');
 * const page = ref(1);
 *
 * const { results, total, totalPages, status } = useSearch({
 *   searchIndexId: 'my-index',
 *   query,
 *   page,
 *   pageSize: 20,
 * });
 */
export declare function useSearch<T extends SearchDocument = SearchDocument>(options: UseSearchOptions<T>): {
    results: import("vue").ComputedRef<T[]>;
    total: import("vue").ComputedRef<number>;
    totalPages: import("vue").ComputedRef<number>;
    error: import("vue").ComputedRef<Error | null>;
    status: import("vue").ComputedRef<SearchStatus>;
    isLoading: import("vue").ComputedRef<boolean>;
    isSuccess: import("vue").ComputedRef<boolean>;
    isError: import("vue").ComputedRef<boolean>;
    isPreviousData: import("vue").ComputedRef<boolean>;
};
//# sourceMappingURL=useSearch.d.ts.map