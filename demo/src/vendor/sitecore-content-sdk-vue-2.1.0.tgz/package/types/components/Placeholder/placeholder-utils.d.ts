import { ComponentRendering, RouteData } from '@sitecore-content-sdk/content/layout';
import { VNode } from 'vue';
import { ComponentMap, VueContentSdkComponent } from '../../sharedTypes';
import { ChildComponentProps, ComponentForRendering, PlaceholderProps } from './models';
/**
 * Get the renderings for the specified placeholder from the rendering layout data.
 * @param {ComponentRendering | RouteData} rendering rendering data
 * @param {string} name placeholder name
 * @param {boolean} isEditing whether components should be rendered in editing mode
 * @returns {ComponentRendering[]} array of component renderings
 */
export declare const getPlaceholderRenderings: (rendering: ComponentRendering | RouteData, name: string, isEditing: boolean) => ComponentRendering<import("@sitecore-content-sdk/content/layout").ComponentFields>[];
/**
 * Get SXA specific params from Sitecore rendering params.
 * @param {ComponentRendering} rendering rendering object
 * @returns {object} converted SXA params
 */
export declare const getSXAParams: (rendering: ComponentRendering) => "" | {
    styles: string;
};
/**
 * Renders an empty placeholder wrapped in a div with the required CSS class for Page Builder edit mode.
 * @param {VNode | VNode[]} node vue node(s)
 * @returns {VNode} wrapped node
 * @public
 */
export declare const renderEmptyPlaceholder: (node: VNode | VNode[]) => VNode;
/**
 * Merge specific placeholder props with component field and params content props.
 * @param {PlaceholderProps} placeholderProps placeholder props
 * @param {ComponentRendering} componentRendering component rendering
 * @returns {ChildComponentProps} merged props
 */
export declare function getChildComponentProps<T extends PlaceholderProps>(placeholderProps: T, componentRendering: ComponentRendering): ChildComponentProps;
/**
 * Get component implementation from the component map based on the rendering definition.
 * @param {ComponentRendering} renderingDefinition rendering data
 * @param {string} placeholderName name of current placeholder
 * @param {ComponentMap} [componentMap] component map for the current app
 * @param {Component} [hiddenRenderingComponent] fallback component when the rendering is hidden
 * @param {Component} [missingComponentComponent] fallback component when no component is found in the component map
 * @returns {ComponentForRendering} component implementation
 */
export declare const getComponentForRendering: (renderingDefinition: ComponentRendering, placeholderName: string, componentMap?: ComponentMap, hiddenRenderingComponent?: VueContentSdkComponent, missingComponentComponent?: VueContentSdkComponent) => ComponentForRendering;
//# sourceMappingURL=placeholder-utils.d.ts.map