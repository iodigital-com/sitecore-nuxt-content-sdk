import { ComponentFields } from '@sitecore-content-sdk/content/layout';
/**
 * Converts datasource item field values into component props.
 * Used in FEaaS and BYOC implementations to pass Sitecore field data to external components.
 * @param {ComponentFields} fields field collection from Sitecore
 * @returns JSON object that can be used as props
 * @public
 */
export declare const getDataFromFields: (fields: ComponentFields) => {
    [key: string]: unknown;
};
//# sourceMappingURL=utils.d.ts.map